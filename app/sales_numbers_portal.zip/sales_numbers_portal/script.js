// Login functionality
document.getElementById("loginForm").addEventListener("submit", function(event) {
  event.preventDefault();
  
  const username = document.getElementById("username").value.trim();
  const password = document.getElementById("password").value.trim();
  const errorMessage = document.getElementById("errorMessage");

  // Email regex: accepts valid typical email addresses
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,6}$/;
  // Password regex: allows typical characters (letters, numbers, and some special characters) with length 8-20
  const passwordRegex = /^[a-zA-Z0-9!@#$%^&*()_+=-]{8,20}$/;
  
  if (!emailRegex.test(username) || !passwordRegex.test(password)) {
    errorMessage.textContent = "Either the username or password is incorrect.";
    errorMessage.style.display = "block";
  } else {
    errorMessage.style.display = "none";
    // Redirect to dashboard page after successful login.
    window.location.href = "dashboard.html";
  }
});

// Logout functionality (works for dashboard page)
function logout() {
  window.location.href = "index.html";
}